from flask import Flask, request, jsonify
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn import svm

# Initialize Flask app
app = Flask(__name__)

# Load dataset
df = pd.read_csv('diabetes_dataset.csv')  # Ensure this file exists in the same folder

# Prepare data
X = df.drop(columns='Outcome', axis=1)
y = df['Outcome']

scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)

# Train model
model = svm.SVC(kernel='linear')
model.fit(X_scaled, y)

@app.route('/')
def home():
    return "Diabetes Prediction API is running."

@app.route('/predict', methods=['POST'])
def predict():
    try:
        data = request.get_json(force=True)
        input_data = np.array([
            data['pregnancies'],
            data['glucose'],
            data['bp'],
            data['skin'],
            data['insulin'],
            data['bmi'],
            data['dpf'],
            data['age']
        ]).reshape(1, -1)

        input_scaled = scaler.transform(input_data)
        prediction = model.predict(input_scaled)[0]

        result = "Diabetic 😟" if prediction == 1 else "Non-Diabetic 🙂"
        return jsonify({'result': result})

    except Exception as e:
        return jsonify({'error': str(e)})

if __name__ == '__main__':
    app.run(debug=True)
